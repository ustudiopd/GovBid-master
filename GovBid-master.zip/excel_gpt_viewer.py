import sys, os, json
import pandas as pd
from dotenv import load_dotenv
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QFileDialog, QTableView, QFrame, QTextBrowser, QTextEdit,
    QSplitter, QLabel
)
from PyQt5.QtGui import QStandardItemModel, QStandardItem
from PyQt5.QtCore import Qt
import requests

# .env에서 GPT 키/모델 불러오기
load_dotenv()
GPT_API_KEY = os.getenv("CHATGPT_API_KEY", "")
GPT_MODEL = os.getenv("CHATGPT_MODEL", "gpt-4.1-mini")

class ExcelGPTViewer(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Excel + GPT 분석기")
        self.setGeometry(100, 100, 1400, 900)
        self.json_path = None
        self.excel_path = None

        # 메인 레이아웃
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        main_layout = QHBoxLayout(main_widget)
        main_layout.setContentsMargins(0, 0, 0, 0)

        # QSplitter(좌:엑셀, 우:챗)
        self.splitter = QSplitter(Qt.Horizontal)
        main_layout.addWidget(self.splitter)

        # 1) 엑셀 뷰어 패널
        excel_panel = QWidget()
        excel_layout = QVBoxLayout(excel_panel)
        excel_layout.setContentsMargins(8, 8, 8, 8)
        file_btn = QPushButton("엑셀 파일 열기")
        file_btn.clicked.connect(self.open_excel)
        excel_layout.addWidget(file_btn)
        self.excel_view = QTableView()
        self.excel_model = QStandardItemModel()
        self.excel_view.setModel(self.excel_model)
        excel_layout.addWidget(self.excel_view)
        self.splitter.addWidget(excel_panel)

        # 2) 챗봇 패널
        chat_frame = QFrame()
        chat_layout = QVBoxLayout(chat_frame)
        chat_layout.setContentsMargins(8, 8, 8, 8)
        chat_layout.setSpacing(8)
        # 모델명 표시
        self.model_label = QLabel(f"모델: {GPT_MODEL}")
        self.model_label.setStyleSheet("font-weight:bold;color:#0057b8;")
        chat_layout.addWidget(self.model_label)
        # 출력창
        self.chat_output = QTextBrowser()
        self.chat_output.setOpenExternalLinks(True)
        self.chat_output.setMinimumHeight(180)
        chat_layout.addWidget(self.chat_output)
        # 구분선
        line = QFrame(); line.setFrameShape(QFrame.HLine); line.setFrameShadow(QFrame.Sunken)
        chat_layout.addWidget(line)
        # 입력창
        self.chat_input = QTextEdit()
        self.chat_input.setPlaceholderText("질문을 입력하세요...")
        self.chat_input.setMinimumHeight(40)
        self.chat_input.setStyleSheet("border:2px solid #000;")
        chat_layout.addWidget(self.chat_input)
        # 버튼
        btn_layout = QHBoxLayout()
        btn_layout.addStretch(1)
        self.send_btn = QPushButton("질문하기")
        self.send_btn.clicked.connect(self.ask_gpt)
        btn_layout.addWidget(self.send_btn)
        btn_layout.addStretch(1)
        btn_widget = QWidget(); btn_widget.setLayout(btn_layout)
        chat_layout.addWidget(btn_widget)
        self.splitter.addWidget(chat_frame)
        self.splitter.setSizes([900, 500])

        # 엑셀 모델 변경 시그널
        self.excel_model.itemChanged.connect(self.on_item_changed)

    def open_excel(self):
        path, _ = QFileDialog.getOpenFileName(self, "엑셀 파일 선택", "", "Excel Files (*.xlsx *.xls)")
        if not path:
            return
        self.excel_path = path
        df = pd.read_excel(path, header=None)
        rows, cols = df.shape
        self.excel_model.clear()
        self.excel_model.setRowCount(rows)
        self.excel_model.setColumnCount(cols)
        for i in range(rows):
            for j in range(cols):
                item = QStandardItem(str(df.iat[i, j]) if not pd.isna(df.iat[i, j]) else "")
                self.excel_model.setItem(i, j, item)
        # JSON 파일 경로
        json_path = os.path.splitext(path)[0] + ".json"
        self.json_path = json_path
        # 초기 JSON 저장
        with open(json_path, "w", encoding="utf-8") as f:
            json.dump(self._model_to_json_schema(), f, ensure_ascii=False, indent=2)

    def on_item_changed(self, item):
        if not self.json_path:
            return
        data_dict = self._model_to_json_schema()
        with open(self.json_path, "w", encoding="utf-8") as f:
            json.dump(data_dict, f, ensure_ascii=False, indent=2)

    def _model_to_json_schema(self):
        # 엑셀→JSON 변환 스키마 (질문에 제시된 예시와 동일)
        model = self.excel_model
        result = {
            "meta": {},
            "items": [],
            "discounts": [],
            "summary": {},
            "comments": ""
        }
        current_category = None
        for row in range(model.rowCount()):
            a = model.item(row, 0).text() if model.item(row, 0) else ""
            d = model.item(row, 3).text() if model.item(row, 3) else ""
            # 1) 섹션 헤더
            if a and not d:
                current_category = a.strip()
                continue
            # 2) 품목 행
            if a and d:
                try:
                    item = {
                        "category": current_category,
                        "description": a.strip(),
                        "unit_price": float(model.item(row, 1).text()) if model.item(row, 1) and model.item(row, 1).text() else 0,
                        "quantity": float(model.item(row, 2).text()) if model.item(row, 2) and model.item(row, 2).text() else 0,
                        "unit_count": float(model.item(row, 3).text()),
                        "amount": float(model.item(row, 4).text()) if model.columnCount() > 4 and model.item(row, 4) and model.item(row, 4).text() else None
                    }
                    result["items"].append(item)
                except Exception:
                    continue
                continue
            # 3) 요약/할인/합계 행 (A열 비어있고 D열에 숫자)
            if not a and d:
                try:
                    val = float(d)
                    if val < 0:
                        result["discounts"].append({"description": "", "amount": -val})
                    else:
                        if "subtotal" not in result["summary"]:
                            result["summary"]["subtotal"] = val
                        elif "tax_amount" not in result["summary"]:
                            result["summary"]["tax_amount"] = val
                        else:
                            result["summary"]["total_due"] = val
                except Exception:
                    continue
                continue
        return result

    def ask_gpt(self):
        user_q = self.chat_input.toPlainText().strip()
        if not user_q or not self.json_path:
            return
        with open(self.json_path, "r", encoding="utf-8") as f:
            quotation_json = f.read()
        messages = [
            {"role": "system", "content": "아래 견적서 JSON을 참고해 질문에 답변해 주세요."},
            {"role": "user", "content": f"견적서 데이터:\n```json\n{quotation_json}\n```\n질문: {user_q}"}
        ]
        answer = ask_gpt_api(messages, GPT_API_KEY, GPT_MODEL)
        self.chat_output.append(f"<b>질문:</b> {user_q}")
        self.chat_output.append(f"<b>GPT:</b>")
        self.chat_output.append(answer)
        self.chat_input.clear()

def ask_gpt_api(messages, api_key, model):
    if not api_key:
        return "[OpenAI API 키를 .env에 입력하세요]"
    url = "https://api.openai.com/v1/chat/completions"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
    data = {
        "model": model,
        "messages": messages,
        "max_tokens": 2048,
        "temperature": 0.7
    }
    try:
        resp = requests.post(url, headers=headers, json=data, timeout=30)
        resp.raise_for_status()
        return resp.json()["choices"][0]["message"]["content"].strip()
    except Exception as e:
        return f"[GPT 호출 오류] {e}"

if __name__ == "__main__":
    app = QApplication(sys.argv)
    viewer = ExcelGPTViewer()
    viewer.show()
    sys.exit(app.exec_()) 